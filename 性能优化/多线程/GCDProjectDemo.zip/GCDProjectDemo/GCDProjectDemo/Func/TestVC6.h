//
//  TestVC6.h
//  GCDProjectDemo
//
//  Created by wangyinghua on 2018/8/25.
//  Copyright © 2018年 ZhiXing. All rights reserved.
//

#import "BaseVC.h"

@interface TestVC6 : BaseVC

@end
